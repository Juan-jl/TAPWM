﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pclasses
{
    class Horista : Empregado
    {
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int Diasfalta { get; set; }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;
        }
        //Override indica sobreescrever
        public override int Tempotrabalho()
        {
            //O método retorna um tipo de span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days - Diasfalta);

        }
    }
}
