﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void BtnInstancial1_Click(object sender, EventArgs e)
        {
            mensalista objMensalista = new mensalista();
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);

            if (rbtnSim.Checked)
                objMensalista.Homeoffice = 'S';
            else
                objMensalista.Homeoffice = 'N';

                //get

                MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" +
                    "Nome: " + objMensalista.NomeEmpregado + "\n" +
                    "Data entrada: " +
                    objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                    "Salário bruto: " + objMensalista.SalarioBruto().ToString("N2") + "\n" +
                    "Tempo empresa: (Dias): " + objMensalista.Tempotrabalho() + "\n" +
                    objMensalista.VerificaHome());
        }
    }
}
